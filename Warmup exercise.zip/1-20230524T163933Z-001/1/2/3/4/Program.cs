﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int[,] pattern = GeneratePattern(6, 5);

        for (int i = 0; i < pattern.GetLength(0); i++)
        {
            for (int j = 0; j < pattern.GetLength(1); j++)
            {
                Console.Write(pattern[i, j] + " ");
            }
            Console.WriteLine();
        }
    }

    static int[,] GeneratePattern(int rows, int columns)
    {
        int[,] pattern = new int[rows, columns];

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                pattern[i, j] = CalculateValue(i + 1, j + 1);
            }
        }

        return pattern;
    }

    static int CalculateValue(int row, int column)
    {
        int value = row;

        for (int i = 1; i < column; i++)
        {
            value *= row + 1;
        }

        return value;
    }
}
