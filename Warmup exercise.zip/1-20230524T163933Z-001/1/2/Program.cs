﻿using System;

class Program
{
    static void Main()
    {
        GeneratePattern();
    }

    static void GeneratePattern()
    {
        // Array of strings representing each layer of the pattern
        string[] layers = {
            "   *                                                                               *",
            "          5                                                                5",
            "                 *                                                  *",
            "                         3                                 3",
            "                                  *                  *",
            "                                            1",
            "                                  *                  *",
            "                         3                                 3",
            "                 *                                                 *",
            "         5                                                                 5",
            "    *                                                                               *"
        };

        foreach (string layer in layers)
        {
            Console.WriteLine(layer);
        }
    }
}