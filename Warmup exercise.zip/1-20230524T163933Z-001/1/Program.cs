﻿using System;

class Program
{
    static void Main(string[] args)
    {
        GenerateDoubleDiamondPattern();
    }

    static void GenerateDoubleDiamondPattern()
    {
        // Generate the upper diamond
        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < Math.Abs(3 - i); j++)
            {
                Console.Write("   ");
            }

            for (int j = 0; j < 2 * (3 - Math.Abs(3 - i)) + 1; j++)
            {
                if (j == 0 || j == 2 * (3 - Math.Abs(3 - i)))
                {
                    Console.Write(" * ");
                }
                else
                {
                    Console.Write("   ");
                }
            }

            Console.WriteLine();
        }

        // Generate the lower diamond
        for (int i = 6; i >= 0; i--)
        {
            for (int j = 0; j < Math.Abs(3 - i); j++)
            {
                Console.Write("   ");
            }

            for (int j = 0; j < 2 * (3 - Math.Abs(3 - i)) + 1; j++)
            {
                if (j == 0 || j == 2 * (3 - Math.Abs(3 - i)))
                {
                    Console.Write(" * ");
                }
                else
                {
                    Console.Write("   ");
                }
            }

            Console.WriteLine();
        }
    }
}